# Third-party notices

Night City Save Editor is distributed under GPL-3.0-only; see LICENSE.

The binary format implementation was developed with reference to WolvenKit's
save readers and writers (GPL-3.0), including LZ4 framing, RED packages, facts,
items, appearance and persistency data. The optimized 2.5 stats layout was
investigated against the supplied macOS save.

- WolvenKit: https://github.com/WolvenKit/WolvenKit
- Reference commit: 4e0c851f6b192822a139f7adf101a7609f86a431
- assets/items.json: item record names extracted from WolvenKit.Common/Resources/tweakdbstr.kark.
  Only the record-name catalog is shipped; no Oodle/kraken library is required at runtime.
  The extraction script accepts an already decompressed table.

assets/item_metadata.json is a generated dictionary of item identifiers, English
item titles, item types, categories and iconic/recipe flags read from a locally
installed Cyberpunk 2077 2.5 copy (base game and Phantom Liberty). It contains no
archives, scripts, descriptions, textures or decompression library. Records whose
displayName contains an entire message are exported without that text. Missing
record strings are represented by their numeric TweakDBID. The reproducible
extractor is scripts/extract_item_metadata.py; it accepts tweakdb.bin files and
already decompressed English onscreens CR2W resources. Resource aliases for the
editor's existing ammunition stack IDs are supplied separately by the UI catalog.

The fact and vehicle dictionaries and default appearance presets are from CyberCAT-SimpleGUI (MIT):

- https://github.com/Deweh/CyberCAT-SimpleGUI
- Reference commit: c1fd00305e7db905a4e7de8cfa360d4f4efee3b2
- assets/facts.json, assets/vehicles.json, assets/appearance_male.json, assets/appearance_female.json
- Copyright and permission notice: assets/CyberCAT-LICENSE

The bundled appearance presets include local 2.5 cyberarm corrections and
additional elemental groups. The male arm groups, slot labels and perspective
routing were checked against a natively male 2.5 save and updated accordingly. assets/cyberarm_definitions_25.json contains only
resource hashes and appearance-definition identifiers read from a locally installed
Cyberpunk 2077 2.5 copy. It excludes game resource files and dismemberment config
names. scripts/extract_cyberarm_definitions.py reproduces this catalog from already
decompressed CR2W resources. No archive extractor or decompressor is distributed.

Cargo dependency licenses are specified by the corresponding packages and are
recorded by the exact versions in Cargo.lock. Main runtime dependencies include
eframe/egui (MIT OR Apache-2.0), rfd (MIT), lz4_flex (MIT), anyhow
(MIT OR Apache-2.0), serde (MIT OR Apache-2.0), serde_json (MIT OR Apache-2.0),
and crc32fast (MIT OR Apache-2.0). The applications do not contain or require
CyberCAT, WolvenKit, .NET, or a local game installation at runtime.

Cyberpunk 2077 is a trademark of CD PROJEKT. This is an unofficial project.

The experimental iconic catalog (assets/iconic_weapons.json) combines a
user-supplied weapon list with short English summaries and numeric native part
references / DualWield tags from local 2.5 TweakDB files. The reproducible blueprint
extractor is scripts/extract_weapon_blueprints.py (base file, then expansion).
Weapon artwork was supplied in iconsItems/weapons/uniq; the bundled PNG files in
assets/iconic_weapons are format conversions of those images. Cyberpunk artwork
and weapon names remain the property of their respective rights holders.
The PNG decoder uses the image crate (MIT OR Apache-2.0).

assets/weapon_quality_curves_25.json contains only four numeric curve tables from
local 2.5 CurveSet resources. scripts/extract_weapon_quality_curves.py reproduces
it from already decompressed quality_curves and random_distributions resources.
The tables validate initial tier selection and native upgrade-stage progression;
no original CurveSet files or decompression library are distributed.
